%This code is used to verify Lemma 8. The basic idea is to verify the
%equality of E{<skew(Z'),E><skew(Z'),E>} and E{<R_iskew(R_jZ'R_j')R_i,R_kER_k>
%<R_iskew(R_jZ'R_j')R_i,R_kER_k>}.

% Copyright (C) 2018 by Yongbo Chen
%% ------------------------------------------
% Input: None
% Output: The covariance of two equations
% -------------------------------------------
%% Coding
% Inilization
clc
clear
close all
% Main code
R_i=so3_exp(rand(3,1)); % Random rotation matrix
R_j=so3_exp(rand(3,1));
R_k=so3_exp(rand(3,1));
k=200; %concentration $\kappa_{ij}$ of isotropic Langevin distribution
N_i=10000; %N_i Loops for expectation (Recommend N_i>5000)
E1=[0,0,0;0,0,1;0,-1,0]/sqrt(2);%Basises
E2=[0,1,0;-1,0,0;0,0,0]/sqrt(2);
E3=[0,0,-1;0,0,0;1,0,0]/sqrt(2);
for i=1:1:N_i 
    Z_ij=randlangevin(3, k); %random rotation Langevin distribution by Nicolas Boumal
    grad=k*R_i*m_skew(R_j*Z_ij'*R_j')*R_i'; %R_iskew(R_jZ'R_j')R_i'
    grad1=k*m_skew(Z_ij');%skew(Z')
    f(i)=trace(grad'*R_k*E1*R_k')*trace(grad'*R_k*E1*R_k');
    f1(i)=trace(grad1'*E1)*trace(grad1'*E1);
    X = ['mean_f:  ',num2str(mean(f)),'mean_f1:  ',num2str(mean(f1))];
    disp(X);
end
mean(f)%E{<R_iskew(R_jZ'R_j')R_i,R_kER_k><R_iskew(R_jZ'R_j')R_i,R_kER_k>}
mean(f1)%E{<skew(Z'),E><skew(Z'),E>}