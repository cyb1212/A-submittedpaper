function [ result ] = so3_exp( x )
% compute the exponential mapping of R^3 to SO(3)
% use sparse matrix
% Copyright (C) 2018 by Yongbo Chen
	N = size(x,1);
    theta=norm(x);
    if theta==0
        result=eye(3);
    else     
        omega =x/theta;
        result=eye(3,3) + sin(theta) * skew(omega) + (1 - cos(theta))*skew(omega)^2;  
    end
end

