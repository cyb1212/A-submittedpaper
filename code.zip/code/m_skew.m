function y = m_skew( x )
% compute the skew symetric matrix 
% given input 3x3 matrix x
% Copyright (C) 2018 by Yongbo Chen
y=(x-x')/2;
end